import pandas as pd
pd.set_option('display.max_colwidth', -1)
